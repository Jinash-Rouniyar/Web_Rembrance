document.addEventListener("DOMContentLoaded", function() {
    const viewer = document.getElementById('pdf-viewer');
    const zoomInButton = document.getElementById('zoom-in');
    const zoomOutButton = document.getElementById('zoom-out');

    // Load the converted PDF content
    fetch('sat.html') // Adjust this path to your actual file location
        .then(response => response.text())
        .then(data => {
            viewer.innerHTML = data;
        })
        .catch(error => {
            console.error('Error loading PDF content:', error);
            viewer.innerHTML = '<p>Failed to load PDF content. Please try again later.</p>';
        });

    // Zoom functions
    zoomInButton.addEventListener('click', function() {
        adjustFontSize(1.2);
    });

    zoomOutButton.addEventListener('click', function() {
        adjustFontSize(0.8);
    });

    function adjustFontSize(scale) {
        const elements = viewer.querySelectorAll('*');
        elements.forEach(el => {
            const computedStyle = window.getComputedStyle(el, null);
            const fontSize = computedStyle.getPropertyValue('font-size');
            const newSize = parseFloat(fontSize) * scale;
            el.style.fontSize = newSize + 'px';
        });
    }
});
